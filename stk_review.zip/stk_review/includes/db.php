<?php
class DBController {

    private $hostname  =   "localhost";

    private $username  =   "root";

    private $password  =   "";

    private $db        =   "stk_review";

    //create connection
    public function connect() {

        $conn = new mysqli($this->hostname, $this->username, $this->password, $this->db)or die("Database connection error." . $conn->connect_error);

        return $conn;
    }

    // close connection
    public function close($conn) {

        $conn->close();

    }
}
$base_url ="http://localhost:8080/stk_review/Controllers/";
$femail = 'sum@nishatbrothers.com';
?>